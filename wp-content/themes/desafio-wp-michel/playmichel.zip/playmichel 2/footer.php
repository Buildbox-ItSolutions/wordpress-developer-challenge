
        </main>
        <footer class="bg-dark pe-2 ps-2 pt-5 text-white"> 
            <div class="container-md "> 
                <div class="pb-5 pb-sm-0 row"> 
                    <div class="align-items-center align-items-sm-start d-flex flex-column gap-3 pb-5 pb-sm-3 pt-3 py-3"> <a href="#" class=""><img src="<?php echo get_template_directory_uri(); ?>/assets/img/logo-play.svg" width="70px"/></a> 
                        <p class="mb-5 mb-sm-5 text-center"><?php _e( '© 2020 — Play — Todos os direitos reservados.', 'play_michel' ); ?></p> 
                    </div>                     
                </div>                 
            </div>             
        </footer>
        <?php wp_footer(); ?>
    </body>
</html>
